//
//  TaskModel.swift
//  TaskManagerD4
//
//  Created by Rawan on 12/09/1446 AH.
//
import Foundation

struct Task: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var details: String
    var isCompleted: Bool
}


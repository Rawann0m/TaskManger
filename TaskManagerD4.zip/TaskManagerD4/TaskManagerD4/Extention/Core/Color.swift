//
//  Color.swift
//  TaskManagerD4
//
//  Created by Rawan on 12/09/1446 AH.
//
import SwiftUICore
extension Color{
    static let color0 = Color("CustomColor")
}

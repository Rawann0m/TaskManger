//
//  AddTaskView.swift
//  TaskManagerD4
//
//  Created by Rawan on 12/09/1446 AH.
//

import SwiftUI

struct AddTaskView: View {
    @ObservedObject var taskViewModel: TaskViewModel
    @State private var newTask = ""
    @State private var details = ""
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1)
                    .edgesIgnoringSafeArea(.all)
                HStack {
                    VStack {
                        TextField("Enter new task", text: $newTask)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding()
                            .dynamicTypeSize(.large ... .xxLarge)
                            .accessibilityLabel("New task field")
                            .accessibilityHint("Type the name of the task here")

                        TextField("Enter the task details", text: $details)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding()
                            .dynamicTypeSize(.large ... .xxLarge)
                            .accessibilityLabel("New task details field")
                            .accessibilityHint("Type the details of the task here")
                    }

                    Button(action: addTask) {
                        Image(systemName: "plus")
                            .padding()
                            .background(Color.color0)
                            .foregroundColor(.white)
                            .clipShape(Circle())
                            .dynamicTypeSize(.large ... .xxLarge)
                            .accessibilityLabel("Confirm add task")
                            .accessibilityHint("Adds the task to the list")
                    }
                    .padding(.trailing)
                }
                .navigationTitle("New Task")
            }
        }
    }

    private func addTask() {
        taskViewModel.addTask(title: newTask, details: details)
        dismiss()
    }
}

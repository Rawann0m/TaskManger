//
//  TaskViewModel.swift
//  TaskManagerD4
//
//  Created by Rawan on 12/09/1446 AH.
//
import SwiftUI

class TaskViewModel: ObservableObject {
    @Published var tasks: [Task] = [
        Task(title: "Complete project", details: "SwiftUI project", isCompleted: false),
        Task(title: "Read a book", details: "Read for 30 minutes", isCompleted: false),
        Task(title: "Go for a walk", details: "For 20 minutes", isCompleted: true)
    ]

    @Published var isDarkMode = false

    // Add a new task
    func addTask(title: String, details: String) {
        withAnimation(.spring()) {
            guard !title.isEmpty else { return }
            tasks.append(Task(title: title, details: details, isCompleted: false))
        }
    }

    // Toggle task completion
    func toggleTaskCompletion(task: Task) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            withAnimation {
                tasks[index].isCompleted.toggle()
            }
        }
    }

    // Delete task
    func deleteTask(at offsets: IndexSet) {
        withAnimation(.easeInOut) {
            tasks.remove(atOffsets: offsets)
        }
    }

    // Sort tasks
    var sortedTasks: [Task] {
        tasks.sorted { !$0.isCompleted && $1.isCompleted }
    }
}

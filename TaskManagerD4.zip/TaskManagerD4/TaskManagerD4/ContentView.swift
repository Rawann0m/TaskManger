//
//  ContentView.swift
//  TaskManagerD4
//
//  Created by Rawan on 12/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var taskViewModel = TaskViewModel()

    var body: some View {
        NavigationStack {
            VStack {
                // Add Task Navigation Link
                NavigationLink(destination: AddTaskView(taskViewModel: taskViewModel)) {
                    Text("Add Task")
                        .font(.subheadline)
                        .padding()
                        .foregroundColor(.purple)
                        .dynamicTypeSize(.large ... .xxLarge)
                        .accessibilityLabel("Add a new task")
                        .accessibilityHint("Opens the add task screen")
                }
                .padding(5)

                // Task List
                List {
                    ForEach(taskViewModel.sortedTasks) { task in
                        TaskRowView(task: task, viewModel: taskViewModel)
                    }
                    .onDelete(perform: taskViewModel.deleteTask)
                }
                .background(.gray.opacity(0.1))
                .navigationTitle("To-Do List")
                .preferredColorScheme(taskViewModel.isDarkMode ? .dark : .light)

                // Dark Mode Toggle
                Toggle("Dark Mode", isOn: $taskViewModel.isDarkMode)
                    .padding()
                    .accessibilityHint("Toggles dark mode for better visibility")
            }
        }
    }
}

#Preview {
    ContentView()
}

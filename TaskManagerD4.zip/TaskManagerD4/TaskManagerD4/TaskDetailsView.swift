//
//  TaskDetailsView.swift
//  TaskManagerD4
//
//  Created by Rawan on 12/09/1446 AH.
//

import SwiftUI

struct TaskDetailView: View {
    let task: Task

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(task.title)
                .font(.title)
                .fontWeight(.bold)

            Text(task.details)
                .font(.body)
                .foregroundColor(.gray)

            Spacer()
        }
        .padding()
        .navigationTitle("Task Details")
    }
}

//
//  TaskRowView.swift
//  TaskManagerD4
//
//  Created by Rawan on 13/09/1446 AH.
//
import SwiftUI

struct TaskRowView: View {
    let task: Task
    @ObservedObject var viewModel: TaskViewModel

    var body: some View {
        HStack {
            // Checkmark Button
            Button {
                viewModel.toggleTaskCompletion(task: task)
            } label: {
                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(task.isCompleted ? .green : .gray)
            }
            .buttonStyle(.plain) // Ensure the button doesn't interfere with the NavigationLink

            // Task Details (Navigation Area)
            NavigationLink(destination: TaskDetailView(task: task)) {
                VStack(alignment: .leading) {
                    Text(task.title)
                        .strikethrough(task.isCompleted, color: .gray)
                        .foregroundColor(task.isCompleted ? .gray : .primary)
                        .dynamicTypeSize(.large ... .xxLarge)
                    Text(task.details)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                .contentShape(Rectangle()) // Make the entire area tappable
            }
            .buttonStyle(.plain) // Ensure the NavigationLink doesn't interfere with the button
        }
        .padding()
    }
}

//
//  TaskManagerD4App.swift
//  TaskManagerD4
//
//  Created by Rawan on 12/09/1446 AH.
//

import SwiftUI

@main
struct TaskManagerD4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
